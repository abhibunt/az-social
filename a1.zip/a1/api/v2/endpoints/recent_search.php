<?php
$response_data = array(
                    'api_status' => 200,
                    'data' => Wo_GetRecentSerachs()
                );