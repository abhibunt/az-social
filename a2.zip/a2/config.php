<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - The Ultimate PHP Social Networking Platform
// | Copyright (c) 2017 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
@header('Location: install');
exit();
// MySQL Hostname
$sql_db_host = "db_name";
// MySQL Database User
$sql_db_user = "db_user";
// MySQL Database Password
$sql_db_pass = "db_pass";
// MySQL Database Name
$sql_db_name = "db_name";

// Site URL
$site_url = "site_url"; // e.g (http://example.com)
?>