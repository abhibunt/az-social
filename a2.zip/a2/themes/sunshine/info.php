<?php
$themeName = 'Sunshine';

$themeFolder = 'sunshine';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'https://codecanyon.net/user/doughouzforest/';

$themeVirsion = '1.0';

$themeImg = $themeFolder . '/themeLogo.png';
?>